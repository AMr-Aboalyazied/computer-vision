# Yolo-Object-Detection
The theoretical part is Yolo and the practical part using open cv library

https://www.kaggle.com/msambare/fer2013
